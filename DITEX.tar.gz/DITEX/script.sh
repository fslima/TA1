#! /bin/bash

#Esse script deve ser executado com SUDO

#Instalando o Django 1.3.1
tar xzvf Django-1.3.1.tar.gz
python Django-1.3.1/setup.py install

#Instalando o POSTGRE 8.4
apt-get install postgresql-8.4
apt-get install python-pgsql

#Configurando o Sistema do Ditex
chmod 777 /opt
cp -a tpcavancados /opt
sudo -u postgres createdb BancoDitex
python /opt/tpcavancados/manage.py syncdb
