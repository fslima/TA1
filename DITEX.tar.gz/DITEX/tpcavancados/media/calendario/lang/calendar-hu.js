// ** I18N
Calendar._DN = new Array
("Vas�rnap",
 "H�tf�",
 "Kedd",
 "Szerda",
 "Cs�t�rt�k",
 "P�ntek",
 "Szombat",
 "Vas�rnap");
Calendar._MN = new Array
("janu�r",
 "febru�r",
 "m�rcius",
 "�prilis",
 "m�jus",
 "j�nius",
 "j�lius",
 "augusztus",
 "szeptember",
 "okt�ber",
 "november",
 "december");

// tooltips
Calendar._TT = {};
Calendar._TT["TOGGLE"] = "Toggle first day of week";
Calendar._TT["PREV_YEAR"] = "El�z� �v (hold for menu)";
Calendar._TT["PREV_MONTH"] = "El�z� h�nap (hold for menu)";
Calendar._TT["GO_TODAY"] = "Mai napra ugr�s";
Calendar._TT["NEXT_MONTH"] = "K�v. h�nap (hold for menu)";
Calendar._TT["NEXT_YEAR"] = "K�v. �v (hold for menu)";
Calendar._TT["SEL_DATE"] = "V�lasszon d�tumot";
Calendar._TT["DRAG_TO_MOVE"] = "Drag to move";
Calendar._TT["PART_TODAY"] = " (ma)";
Calendar._TT["MON_FIRST"] = "H�tf� legyen a h�t els� napja";
Calendar._TT["SUN_FIRST"] = "Vas�rnap legyen a h�t els� napja";
Calendar._TT["CLOSE"] = "Bez�r";
Calendar._TT["TODAY"] = "Ma";

// date formats
Calendar._TT["DEF_DATE_FORMAT"] = "y-mm-dd";
Calendar._TT["TT_DATE_FORMAT"] = "M d, D";

Calendar._TT["WK"] = "h�t";
